exports.run = {
   usage: ['prod12'],
   async: async (m, {
      client,
      isPrefix,
      command,
      Func
   }) => {
      try {
         const buttons = [{
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
               title: 'JENIS AKUN',
               sections: [{
                  rows: [{
                     title: 'INDIVIDUAL',
                     // description: `X`,
                     id: `${isPrefix}duoindi`
                  }, {
                     title: 'FAMILY',
                     // description: `Y`,
                     id: `${isPrefix}duofamily`
                  }]
               }]
            })
         }];

         // Ganti URL_GAMBAR dengan link gambar yang diinginkan
         const imageUrl = 'https://i.ibb.co.com/m6CS3NY/Screenshot-28-10-2024-94442-www-instagram-com.jpg'; 

         client.sendIAMessage(m.chat, buttons, m, {
            header: '',
            content: `*DUOLINGO SUPER* \n
💵 Rp30.000 = 1 Bulan Individu
💵 Rp220.000 = 12 Bulan Individu
💵 Rp280.000 = 12 Bulan Family

✅ Akun Dari Pembeli
✅ Bisa perpanjang
✅ Full Garansi

*SILAHKAN PILIH JENIS AKUN:*`,
            media: imageUrl // Ganti dengan URL gambar
         });
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   cache: true,
   location: __filename
}
