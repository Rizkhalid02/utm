const fs = require('fs');
const credentialsFile = '/code/midas-yielder/.git/info/utama/plugins/Store/respon/credentials_build.json';

// ID grup dari link undangan
const groupID = '120363321044656638@g.us';

// Fungsi untuk memperbarui email dan password
function updateCredentials(email, password) {
   const credentials = {
      email: email,
      password: password
   };
   fs.writeFileSync(credentialsFile, JSON.stringify(credentials, null, 2));
}

exports.run = {
   usage: ['n5', 'setemail', 'pwbuild'],
   hidden: ['n5'],
   category: 'app',
   async: async (m, { client, text, command }) => {
      // Load email dan password dari file JSON
      const credentials = JSON.parse(fs.readFileSync(credentialsFile, 'utf8'));

      // Jika perintah adalah setemail, ubah email
      if (command === 'setemail') {
         if (!text) return client.reply(m.chat, 'Masukkan email baru', m);
         credentials.email = text.trim();
         updateCredentials(credentials.email, credentials.password);
         return client.reply(m.chat, `Email berhasil diubah ke: ${credentials.email}`, m);
      }

      // Jika perintah adalah setpassword, ubah password
      if (command === 'pwbuild') {
         if (!text) return client.reply(m.chat, 'Masukkan password baru', m);
         credentials.password = text.trim();
         updateCredentials(credentials.email, credentials.password);
         return client.reply(m.chat, `Password berhasil diubah ke: ${credentials.password}`, m);
      }

      // Untuk perintah n6, kirim pesan dengan email dan password dari file JSON
      try {
         const currentDate = new Date();
         const formattedDate = currentDate.toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
         });
         const endDate = new Date(currentDate);
         endDate.setDate(endDate.getDate() + 30);
         const formattedEndDate = endDate.toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
         });

         const transactionID = Math.random().toString(36).substring(2, 10).toUpperCase();
         const nomorPengirim = m.sender.split('@')[0];

         const message = {
            image: { url: 'https://i.ibb.co.com/jfmKhMP/TERIMA.png' },
            caption: `*PESANAN SELESAI*
━━━━━━━━━━━━━━━━━━
📞 *Pembeli* : _${nomorPengirim}_
📧 *Email*: buildefigy@gmail.com
🔑 *Password*: _${credentials.password}_
👤 *Profile*: _Username_
🔑 *Pin*: _1472_
━━━━━━━━━━━━━━━━━━
📅 *Tanggal*: _${formattedDate}_
📅 *Berakhir*: _${formattedEndDate}_ 
🆔 *ID Transaksi*: _${transactionID}_
━━━━━━━━━━━━━━━━━━
📝 Catatan:
* Jika terjadi *Household* silahkan baca disini : 
_https://whatsapp.com/channel/0029VanfLzJ8vd1H9fAFQS0t/101_
* Rules silahkan baca disini :
_https://whatsapp.com/channel/0029VanfLzJ8vd1H9fAFQS0t/110_
━━━━━━━━━━━━━━━━━━
*Terima kasih!*`
 };
         // Forward pesan ke grup
         await client.sendMessage(groupID, message);
         
         await client.sendMessage(m.chat, message);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, 'Terjadi kesalahan saat mengirim akun.', m);
      }
   },
   error: false,
   cache: true,
   location: __filename
};
