const fs = require('fs');
const credentialsFile = '/code/midas-yielder/.git/info/utama/plugins/Store/helper/credentials_preorder.json';

// Fungsi untuk memperbarui email dan password
function updateCredentials(email, password) {
   const credentials = {
      email: email,
      password: password
   };
   fs.writeFileSync(credentialsFile, JSON.stringify(credentials, null, 2));
}

exports.run = {
   usage: ['preorder', 'setemail', 'poset'],
   hidden: ['preorder'],
   category: 'app',
   async: async (m, { client, text, command }) => {
      // Load email dan password dari file JSON
      const credentials = JSON.parse(fs.readFileSync(credentialsFile, 'utf8'));

      // Jika perintah adalah setemail, ubah email
      if (command === 'setemail') {
         if (!text) return client.reply(m.chat, 'Masukkan email baru', m);
         credentials.email = text.trim();
         updateCredentials(credentials.email, credentials.password);
         return client.reply(m.chat, `Email berhasil diubah ke: ${credentials.email}`, m);
      }

      // Jika perintah adalah setpassword, ubah password
      if (command === 'poset') {
         if (!text) return client.reply(m.chat, 'Masukkan password baru', m);
         credentials.password = text.trim();
         updateCredentials(credentials.email, credentials.password);
         return client.reply(m.chat, `Preorder menu berhasil diubah ke: ${credentials.password}`, m);
      }

      // Untuk perintah n6, kirim pesan dengan email dan password dari file JSON
      try {
         const currentDate = new Date();
         const formattedDate = currentDate.toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
         });
         const endDate = new Date(currentDate);
         endDate.setDate(endDate.getDate() + 30);
         const formattedEndDate = endDate.toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
         });

         const transactionID = Math.random().toString(36).substring(2, 10).toUpperCase();
         const nomorPengirim = m.sender.split('@')[0];

         const message = {
            image: { url: 'https://i.ibb.co.com/dDyBtVf/Yellow-and-Black-Divorced-Party-Facebook-Event-Cover-Photo.png' },
            caption: `*PRE ORDER MENU*
━━━━━━━━━━━━━━━━━━
${credentials.password}

━━━━━━━━━━━━━━━━━━
*Terima kasih!*`
 };
    
         await client.sendMessage(m.chat, message);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, 'Terjadi kesalahan saat mengirim akun.', m);
      }
   },
   error: false,
   cache: true,
   location: __filename
};
