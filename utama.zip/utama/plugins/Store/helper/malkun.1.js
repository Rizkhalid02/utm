exports.run = {
   usage: ['malkun'],
   async: async (m, {
      client,
      isPrefix,
      command,
      Func
   }) => {
      try {
         // Membuat button dengan JSON
         const buttons = [{
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
               title: 'PILIHAN',
               sections: [{
                  rows: [{
                     title: '🗝️ GET KODE',
                     id: `${isPrefix}account`
                  },{
                     title: '☎️ CHAT ADMIN',
                     id: `${isPrefix}confess 6289653898291 | Request Password`
                  }]
               }]
            })
         }];
          // Mengirim pesan dengan gambar yang ditambahkan ke menu tanpa footer dan media dari db
         client.sendIAMessage(m.chat, buttons, m, {
            header: '',
            content: `*PERMASALAHAN PADA AKUN*\n
━━━━━━━━━━━━━━━━━━
⚠️ *Malas Membaca = Tidak akan solved*
━━━━━━━━━━━━━━━━━━
☰ *NETFLIX HOUSEHOLD*

◧ *Muncul* :
* *TV-mu bukan bagian dari Rumah...*
* *Perangkatmu bukan bagian dari rumah ...*

_Baca disini untuk mengatasinya : https://whatsapp.com/channel/0029VanfLzJ8vd1H9fAFQS0t/100_
━━━━━━━━━━━━━━━━━━
☰ *NETFLIX PASSWORD*
Cara supaya nomor kamu mendapatkan broadcast perubahan password pada akun yang kamu gunakan .

_Baca disini : https://whatsapp.com/channel/0029VanfLzJ8vd1H9fAFQS0t/108_
━━━━━━━━━━━━━━━━━━
☰ *MENGAMANKAN AKUN YOUTUBE*
Untuk mengamankan akun youtube agar tidak terkena non aktif / ditangguhkan .

_Baca disini : https://whatsapp.com/channel/0029VanfLzJ8vd1H9fAFQS0t/106_
━━━━━━━━━━━━━━━━━━`,
            footer: '', // Menghapus footer dari global.db
            media: '',
         });
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   cache: true,
   location: __filename
};
