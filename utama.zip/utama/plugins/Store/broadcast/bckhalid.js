const fs = require('fs');
const path = require('path');

exports.run = {
   usage: ['bckhalid'],
   async: async (m, { client, text }) => {
      const filePath = path.join(__dirname, 'broadcastNumberskhalid.json');

      // Cek apakah file ada
      if (!fs.existsSync(filePath)) {
         return client.reply(m.chat, 'File daftar nomor tidak ditemukan!', m);
      }

      let numbers;
      try {
         const data = fs.readFileSync(filePath);
         const parsedData = JSON.parse(data);
         numbers = parsedData.numbers;

         // Cek apakah numbers adalah array
         if (!Array.isArray(numbers)) {
            throw new Error('Data numbers tidak valid');
         }
      } catch (error) {
         return client.reply(m.chat, 'Terjadi kesalahan saat membaca file nomor: ' + error.message, m);
      }

      for (let number of numbers) {
         try {
            await client.sendMessage(number + '@s.whatsapp.net', { text });
            console.log(`Pesan berhasil dikirim ke: ${number}`);
         } catch (error) {
            console.error(`Gagal mengirim pesan ke ${number}: ${error}`);
         }
      }

      client.reply(m.chat, 'Pesan broadcast berhasil dikirim!', m);
   }
};
