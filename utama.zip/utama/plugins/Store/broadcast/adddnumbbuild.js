const fs = require('fs');
const path = require('path');

exports.run = {
   usage: ['addbuild'],
   async: async (m, { client, text }) => {
      const filePath = path.join(__dirname, 'broadcastNumbersbuild.json');
      let numbers;

      // Cek apakah file ada
      if (!fs.existsSync(filePath)) {
         numbers = { numbers: [] }; // Jika file tidak ada, buat array baru
      } else {
         numbers = JSON.parse(fs.readFileSync(filePath));
      }

      // Memastikan nomor yang ditambahkan tidak duplikat
      if (!numbers.numbers.includes(text)) {
         numbers.numbers.push(text);
         fs.writeFileSync(filePath, JSON.stringify(numbers, null, 2));
         client.reply(m.chat, `Nomor ${text} berhasil ditambahkan ke list broadcast!`, m);
      } else {
         client.reply(m.chat, `Nomor ${text} sudah ada di list broadcast.`, m);
      }
   }
};
